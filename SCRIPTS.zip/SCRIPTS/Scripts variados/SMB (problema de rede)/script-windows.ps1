# Executar como administrador!
 
Write-Host "Iniciando configura��o de servi�os e SMB..." -ForegroundColor Cyan
 
# Ativar servi�os LanmanWorkstation e LanmanServer
Set-Service -Name LanmanWorkstation -StartupType Automatic
Set-Service -Name LanmanServer -StartupType Automatic
Start-Service -Name LanmanWorkstation
Start-Service -Name LanmanServer
Write-Host "Servi�os LanmanWorkstation e LanmanServer ativados." -ForegroundColor Green
 
# Ativar SMBv2 (SMB 2.0 e 3.0 j� v�m ativados no Windows 10+ por padr�o)
Set-SmbServerConfiguration -EnableSMB2Protocol $true -Force
Write-Host "SMBv2 ativado." -ForegroundColor Green
 
# Opcional: Ativar SMBv1 (n�o recomendado)
$ativarSMBv1 = Read-Host "Deseja ativar SMBv1 (inseguro)? (s/n)"
if ($ativarSMBv1 -eq "s") {
    Enable-WindowsOptionalFeature -Online -FeatureName "SMB1Protocol" -NoRestart
    Write-Host "SMBv1 ativado (aten��o: inseguro!)." -ForegroundColor Yellow
} else {
    Write-Host "SMBv1 n�o ser� ativado." -ForegroundColor Cyan
}
 
# Corrigir configura��es de assinatura SMB no registro
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" -Name "RequireSecuritySignature" -Value 0 -PropertyType DWord -Force
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" -Name "EnableSecuritySignature" -Value 1 -PropertyType DWord -Force
Write-Host "Configura��es de assinatura SMB ajustadas." -ForegroundColor Green
 
# Recarregar pol�ticas de grupo (se necess�rio)
gpupdate /force
 
Write-Host "`nConfigura��o conclu�da. Reinicie o computador se necess�rio." -ForegroundColor Cyan